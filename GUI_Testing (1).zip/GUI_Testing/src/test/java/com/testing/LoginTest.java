package com.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;

public class LoginTest extends BaseTest {

    @Test
    public void loginTest() {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        try {
            // MORE FLEXIBLE LOCATOR (works in most React navbars)
            By loginLocator = By.xpath(
                    "//a[contains(translate(text(),'LOGIN','login'),'login') " +
                    "or contains(translate(text(),'SIGN IN','sign in'),'sign') " +
                    "or //button[contains(.,'Login') or contains(.,'Sign')]]"
            );

            WebElement loginBtn = wait.until(
                    ExpectedConditions.elementToBeClickable(loginLocator)
            );

            loginBtn.click();

            System.out.println("Login clicked successfully");

        } catch (TimeoutException e) {
            System.out.println("Login element NOT found on page");
            System.out.println("Current URL: " + driver.getCurrentUrl());
            System.out.println("Page Title: " + driver.getTitle());

            Assert.fail("Login button not found. Fix your locator or UI text.", e);
        }
    }
}