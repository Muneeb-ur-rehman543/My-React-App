package com.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;

@SuppressWarnings("unused")
public class EndtoendTest extends BaseTest {

    @Test
    public void fullUserJourneyTest() {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // =========================
        // STEP 1: Open Homepage
        // =========================
        driver.get("http://localhost:5173");
        System.out.println("Homepage opened: http://localhost:5173");

        // =========================
        // STEP 2: Click HTML Tutorial
        // =========================
        wait.until(ExpectedConditions.elementToBeClickable(By.linkText("HTML"))).click();
        System.out.println("Clicked: HTML Tutorial");
        Assert.assertTrue(driver.getCurrentUrl().toLowerCase().contains("learnhtml") ||
                driver.getCurrentUrl().toLowerCase().contains("html"));
        System.out.println("HTML page opened successfully");

        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a.navbar-brand"))).click();
        System.out.println("Back to Home clicked");

        // =========================
        // STEP 3: Click Exercise Page
        // =========================
        wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Exercises"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.linkText("HTML Exercises"))).click();
        System.out.println("Clicked: Exercise Page");
        Assert.assertTrue(driver.getCurrentUrl().toLowerCase().contains("exercisehtml") ||
                driver.getCurrentUrl().toLowerCase().contains("exercise"));
        System.out.println("Exercise page opened successfully");

        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a.navbar-brand"))).click();
        System.out.println("Back to Home clicked");

        System.out.println("PASSED: fullUserJourneyTest");
    }
}