package com.testing;

import org.testng.Assert;
import org.testng.annotations.Test;

public class HomePageTestNG extends BaseTest {

    @Test
    public void verifyHomePageTitle() {
        String title = driver.getTitle();

        System.out.println("Title: " + title);

        Assert.assertEquals(title, "Vite + React");
    }
}