package com.testing;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HomePageTest {

    public static void main(String[] args) {

        // Create Chrome browser
        WebDriver driver = new ChromeDriver();

        // Open your React application
        driver.get("http://localhost:5173");

        // Maximize window
        driver.manage().window().maximize();

        // Print title
        System.out.println("Title: " + driver.getTitle());

        // Wait 5 seconds
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Close browser
        driver.quit();
    }
}