package com.testing;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class NavigationTestNG extends BaseTest {

    @Test
    public void testHTMLPage() throws InterruptedException {
        driver.findElement(By.linkText("HTML")).click();
        Thread.sleep(2000);
        System.out.println("HTML page opened");
    }

    @Test
    public void testCSSPage() throws InterruptedException {
        driver.findElement(By.linkText("CSS")).click();
        Thread.sleep(2000);
        System.out.println("CSS page opened");
    }
}